Here lay the scripts that were useful at a time, now they are kind of
obsoleted by the python script, but you may still find them useful.
